#!/sbin/sh
rm -rf /data/data/com.liquid.control/shared_prefs
rm -rf /data/dalvik-cache
rm -rf /cache/dalvik-cache
